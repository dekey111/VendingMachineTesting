﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachineLibs
{
    public class Calc
    {
        public string GetSumChange( double SumProd, double money )
        {
            string itog = "";
            double change = 0;
            if (money < SumProd)
            {
                itog = "Недостаточно средств";
            }
            else if (money == SumProd)
                itog = "Без сдачи";
            else
            {
                change = SumProd - money;
                itog = $"Сдача: {money}";
            }
            return itog;
        }
    }
}
