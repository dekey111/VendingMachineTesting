﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using VendingMachineLibs;
using System;

namespace VendingMachineLibsTest
{
    [TestClass]
    public class TestCalc
    {
        Calc calc = new Calc();
        //Легкие тесты
        [TestMethod]
        public void GetSumChange_86_86_NoChange()
        {
            string actual = calc.GetSumChange(86, 86);
            string expected = "Без сдачи";
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetQuantityForProduct_100_86_InsufficientFunds()
        {
            string actual = calc.GetSumChange(100, 86);
            string expected = "Недостаточно средств";
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetQuantityForProduct_55_100_Change100()
        {
            string actual = calc.GetSumChange(55, 100);
            string expected = "Сдача: 100";
            Assert.AreEqual(expected, actual);
        }


        //Сложные тесты

        [TestMethod]
        public void GetQuantityForProduct_23455e5_24525_5235_InsufficientFunds()
        {
            string actual = calc.GetSumChange(23455e5, 24525.5235);
            string expected = "Недостаточно средств";
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetSumChange_564544e42_564544e42_NoChange()
        {
            string actual = calc.GetSumChange(564544e42, 564544e42);
            string expected = "Без сдачи";
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetSumChange_22245e1_4242e44_Change4_242Ee47()
        {
            string actual = calc.GetSumChange(22245e1, 4242e44);
            string expected = "Сдача: 4,242E+47";
            Assert.AreEqual(expected, actual);
        }

    }
}
